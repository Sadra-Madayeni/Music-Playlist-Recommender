import subprocess
import sys
import os


def run_script(script_path):
    """Utility function to run a script and handle errors."""
    print(f"\n{'='*50}")
    print(f"Executing: {script_path}")
    print(f"{'='*50}")

    try:
        # Run the script using the current Python executable
        result = subprocess.run([sys.executable, script_path], check=True)
        print(f"-> Successfully completed {script_path}\n")
    except subprocess.CalledProcessError as e:
        print(f"-> ERROR: Script {script_path} failed with exit code {e.returncode}")
        sys.exit(1)


if __name__ == "__main__":
    print("Starting Automated Data Science Pipeline...")

    # Define paths relative to this pipeline.py file
    scripts_dir = "scripts"

    # Step 1: Import raw data to Database (Run this once to setup DB)
    # Check if DB exists, if not, run the importer
    if not os.path.exists("database/dataset.db"):
        run_script(os.path.join(scripts_dir, "import_to_db.py"))
    else:
        print("\nDatabase already exists. Skipping import step.")

    # Step 2: Extract data from DB and Preprocess
    run_script(os.path.join(scripts_dir, "preprocess.py"))

    # Step 3: Feature Engineering and EDA
    run_script(os.path.join(scripts_dir, "feature_engineering.py"))

    print("\n" + "=" * 50)
    print("PIPELINE COMPLETED SUCCESSFULLY!")
    print("=" * 50)
    print(
        "Check your root directory for 'engineered_dataset.csv' and the 'eda_plots/' folder."
    )
